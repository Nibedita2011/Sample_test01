#include<stdio.h>
#include<string.h>

void test() {
	char buff[100] = {0};
	buffer_overflow2(buff);
	printf("buffer_overflow : %s",buff);
}

void buffer_overflow () 
{
	char buff[10] = {0};
	buffer_overflow2(buff);
	printf("buffer_overflow : %s",buff);
}

void buffer_overflow2(char *p) {
	strcpy(p, "This String Will Overflow the Buffer");
}


int main(int argc, char *argv[])
{
	int x = 0;
	char *p = NULL;
	
	x = strlen(argv[1]);
	
	p = (char *)malloc((x-5)*sizeof(char));
	
	strcpy(p, argv[1]);
	
	buffer_overflow () ;
	
	free(p);
}