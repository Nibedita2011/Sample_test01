#include <stdio.h>
#include <unistd.h>

 int main(char* argc, char** argv) {
               char cmd[CMD_MAX] = "/usr/bin/cat ";
               strcat(cmd, argv[1]);
               system(cmd);
       }