// (c) HTB Research
#include "StdAfx.h"
#include <stdlib.h>
#include <stdio.h>
#include <string>
 
int main( int argc, char *argv[] )
{
  char input_data[20];
  printf ("Enter your data: ");
  scanf ("%s", input_data);
  return 0;
}